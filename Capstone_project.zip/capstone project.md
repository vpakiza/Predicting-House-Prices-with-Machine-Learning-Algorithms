AWS Machine Learning Engineer - Capstone Project



Udacity Machine Learning Engineer Nanodegree Program - Capstone Project



Object:

The main aim of my research project is to determine which variables are correlated and how these variables can be used to predict the house prices. Client house sellers want to buy a house  at a reasonable price with the highest return, at the same time, house buyers want to make sure that they want to get a fair price on houses. 

I used AWS SageMaker Studio (JupyterLab) to build the model.


Requirements:

numpy
pandas
scikit-learn
jupyter
matplotlib
seaborn
sklearn


Files:
Capstone Proposal
Capstone Report